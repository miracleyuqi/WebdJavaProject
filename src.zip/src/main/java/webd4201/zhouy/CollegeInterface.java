package webd4201.zhouy;

public interface CollegeInterface {
	public static final String COLLLEGE_NAME = "Durham College";
	public static final String PHONE_NUMBER = "(905)721-2000";
	
	public abstract String getTypeForDisplay();
}
