package webd4201.zhouy;

@SuppressWarnings("serial")
public class DuplicateException extends Exception
{
    public DuplicateException()
    { super();}
    
    public DuplicateException(String message)
    { super(message);}
}
